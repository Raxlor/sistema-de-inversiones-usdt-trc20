# Security Policy

## Supported Versions
tes.

| Version | Supported          |
| ------- | ------------------ |
| Mobil   | :white_check_mark: |
| PC      | :white_check_mark: |
| edg     | :x:                |

