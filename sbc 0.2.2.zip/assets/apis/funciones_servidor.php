<?php 
include '../php/funciones.php';
Contar_referidos_del_cliente();
?>