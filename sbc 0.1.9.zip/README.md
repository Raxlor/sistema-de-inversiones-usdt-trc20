# sistema-de-inversiones-usdt-trc20

 App con deposito automatizado, que ofrece entregar ciertas membresias para invertir en
 ciertos proyecto y optener beneficio a corto y largo plaz y cuentan con funciones tales como.

<li>
 Deposito en USDT auto-dependiente
</li>
<li> Rendimientos diarios lunes-viernes auto-dependiente
</li>
<li> pagos semi-automatico
</li>

