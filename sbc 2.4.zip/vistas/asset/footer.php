<footer class="text-center    text-muted">

    <!-- Copyright -->
    <div class="text-center p-4" style=" background-color: rgb(221 221 221);">
        © <?php echo date('Y') ?> Copyright: NONE
      </div>
    </footer>